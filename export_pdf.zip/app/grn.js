var app = angular.module("myApp", []);

app.controller("myCtrl", function($scope, $http) {

var user_id_session="";
 // alert("Test....");

 checkInternet();

  $scope.logout = function() {
    $http.post("php/logout.php")
    .then(function (result) {
    
    //   console.log(result.data);
       if(result.data == "true") {
     
            window.location.href = "login.html";
  
           }
        
    }, function(result) {
        //some error
        console.log(result);
    });
    
  };


  
  $http.post('php/login_validation.php')
  .then(function (result) {
   // console.log(result.data); 
   //  console.log(result.data.loggedIn);
    if(result.data.loggedIn == "true") {
  
      $scope.user_name1 =result.data.firstname;
      $scope.user_name =result.data.firstname;
      $scope.user_id =result.data.user_id;
      $scope.admin_role =result.data.admin_role;
  
  user_id_session= result.data.user_id;
       
     // console.log(result.data.firstname);
      // window.location.href = "login.html";
  
             
         }else{
  window.location.href = "login.html";
  
         }
      
  }, function(result) {
      //some error
      console.log(result);
  });


  function checkInternet(){
    if (navigator.onLine == true) {
     // alert('Connection active!');
  //   console.log('Connection active!');
    }else{
    alert('Internet connection is lost');
    toastr.warning('Internet connection is lost');
    return;
    }
  }
  
  
  
  
  

  
});


