<?php 

require_once '../includes/db.php';

$Query =  $_REQUEST["Query"];

echo $Query;
?>